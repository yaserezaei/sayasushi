<?php
/**
 * The function below will load Danny's Theme child theme's assets;
 */
add_action( 'wp_enqueue_scripts', 'dannys_child_scripts', 11 );
function dannys_child_scripts() {

	wp_deregister_style( 'dannys-styles' );
    wp_enqueue_style( 'dannys-styles', get_template_directory_uri().'/style.css', '' , true );
    wp_enqueue_style( 'dannys-child', get_stylesheet_uri(), array('dannys-styles') , true );

	/**
	 * Uncomment the line below if you want to add your own custom JavaScript into js/dn_script_child.js file.
     * To uncomment, remove the "//" before the line;
	 */

	// wp_enqueue_script( 'dn_script_child', get_stylesheet_directory_uri() .'/js/dn_script_child.js' , '' , true , true );
}


/**
 * Load child theme's textdomain.
 */
add_action( 'after_setup_theme', 'dannys_load_textdomain' );
function dannys_load_textdomain(){
   load_child_theme_textdomain( 'dannys-child', get_stylesheet_directory().'/languages' );
}