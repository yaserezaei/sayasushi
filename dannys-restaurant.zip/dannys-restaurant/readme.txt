=== Danny's Restaurant ===
Contributors: Hogash
Tags:  restaurant, bar, lounge, pub, delicious, sweet, flavors
Requires at least: 4.7

The ultimate in SEO-ready themes, Dannys Restaurant is a highly extensible theme, featuring an unique frontend pagebuilder that was built for speed and seo.

== Description ==

Dannys Restaurant is one of the most easy to use WordPress themes developed by Hogash. It includes an easy to use pagebuilder that will help you create your entire site in minutes.

Features:

* Frontend Pagebuilder
* WPML & translation ready
* WooCommerce ready with additional WooCommerce features
* Responsive design
* 1 click demo data install
* Multiple Header layouts
* Icon font uploader
* Unlimited sidebars
* Coming Soon features
